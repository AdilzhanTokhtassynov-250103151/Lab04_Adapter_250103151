public class Main {
    public static void main(String[] args) {

        Pizza pizza = new PizzaProxy(
                new PlainPizza()
        );
        System.out.println(pizza.getDescription());
        System.out.println("Total: $" + pizza.getCost());
    }
}