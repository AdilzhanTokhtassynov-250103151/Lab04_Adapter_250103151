public class Pineapple extends PizzaProxy {
    public Pineapple(Pizza pizza) {
        super(pizza);
    }

    public String getDescription() {
        return pizza.getDescription() + ", Pineapple";
    }

    public double getCost() {
        return pizza.getCost() + 1.5;
    }
}