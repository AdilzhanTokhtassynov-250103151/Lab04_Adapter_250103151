public class PizzaProxy implements Pizza {

    protected Pizza pizza;

    public PizzaProxy(Pizza pizza) {
        this.pizza = pizza;
    }

    public String getDescription() {
        System.out.println("Checking pizza...");
        return pizza.getDescription();
    }

    public double getCost() {
        System.out.println("Checking price...");
        return pizza.getCost();
    }
}