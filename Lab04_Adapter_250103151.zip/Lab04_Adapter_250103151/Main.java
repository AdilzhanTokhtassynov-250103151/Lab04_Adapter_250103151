import java.util.List;

public class Main {

    public static void main(String[] args) {
        LegacyBulb rawBulb = new LegacyBulb();
        LegacyThermostat rawThermostat = new LegacyThermostat();
        BulbAdapter bulbAdapter = new BulbAdapter(rawBulb);
        ThermostatAdapter thermostatAdapter = new ThermostatAdapter(rawThermostat);
        List<SmartDevice> deviceList =
                List.of(bulbAdapter, thermostatAdapter);
        ModernHub hub = new ModernHub(deviceList);
        System.out.println("=== ACTIVATE ALL ===");
        hub.activateAll();
        System.out.println("Bulb ON: " + bulbAdapter.isOn());
        System.out.println("Bulb Power: " + bulbAdapter.getPowerPercent() + "%");
        System.out.println("Thermostat ON: " + thermostatAdapter.isOn());
        System.out.println("Thermostat Power: "+ thermostatAdapter.getPowerPercent() + "%");
        System.out.println("Average Power: "+ hub.calculateAveragePowerUsage() + "%");
        System.out.println("\n=== BULB FAULT ===");

        rawBulb.breakFilament();
        System.out.println("Bulb ON: " + bulbAdapter.isOn());
        System.out.println("Bulb Power: "+ bulbAdapter.getPowerPercent() + "%");
        System.out.println("\n=== THERMOSTAT FAULT ===");

        rawThermostat.rotateDial("STUCK");
        System.out.println("Thermostat ON: "+ thermostatAdapter.isOn());
        System.out.println("Thermostat Power: " + thermostatAdapter.getPowerPercent());

        System.out.println("\n=== EMERGENCY SHUTDOWN ===");

        hub.emergencyShutdown();

        System.out.println("Bulb ON: " + bulbAdapter.isOn());

        System.out.println("Thermostat ON: " + thermostatAdapter.isOn());

        System.out.println("Average Power: " + hub.calculateAveragePowerUsage() + "%"
        );
    }
}