public class BulbAdapter implements SmartDevice {
    private final LegacyBulb bulb;
    private final int K = 1;
    public BulbAdapter(LegacyBulb bulb) {
        if (bulb == null) {
            throw new IllegalArgumentException("Bulb cannot be null");
        }
        this.bulb = bulb;
    }
    @Override
    public void turnOn() {
        bulb.setBrightness(255);
    }
    @Override
    public void turnOff() {
        bulb.setBrightness(0);
    }
    @Override
    public boolean isOn() {
        return bulb.hasPower() && bulb.readBrightness() > 0;
    }
    @Override
    public int getPowerPercent() {
        if (!bulb.hasPower()) {
            return 0;
        }
        int raw = bulb.readBrightness();
        if (raw == 0) {
            return 0;
        }
        int rawPercent = (raw * 100) / 255;
        int calibratedPercent = rawPercent + K;
        return Math.min(100, calibratedPercent);
    }
}